<?php
header('Access-Control-Allow_Origin:*');
header('Content-Type: application/json');

include "database.php";
include "fungsi.php";

$id = (isset($_GET["id"])? $_GET["id"] : 0);

if ($_GET["menu"]=="home") {
$sql = 'SELECT * FROM tblhome where id='.$id;
} else if ($_GET["menu"]=="about")  {
$sql = 'SELECT * FROM tblabout where id='.$id;
} else if ($_GET["menu"]=="portofolio")  {
$sql = 'SELECT * FROM tblportofolio where id='.$id;
} else if ($_GET["menu"]=="contact")  {
$sql = 'SELECT * FROM tblcontact where id='.$id;
} else if ($_GET["menu"]=="blog")  {
$sql = 'SELECT * FROM tblblog where id='.$id;
}


$result = mysqli_query($conn,$sql);

$data=array();

$jmlData = mysqli_num_rows($result);

if ($jmlData >0){
    $row = mysqli_fetch_assoc($result);
    $data = $row;
}else{

    $data['error'] = 'Data Tidak ditemukan atau invalid id';
}

echo json_encode($data);

?>