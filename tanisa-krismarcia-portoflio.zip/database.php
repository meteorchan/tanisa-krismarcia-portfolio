<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "web_portofolio";

$conn = mysqli_connect($serverName, $userName, $password, $dbName);
if(!$conn){
    die("Koneksi Gagal");
}

?>