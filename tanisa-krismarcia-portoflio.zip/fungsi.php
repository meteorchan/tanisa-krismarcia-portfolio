<?php

function potong($artikel, $wordLimit, $id){
    $word = explode(" ", $artikel);  
    $result = implode(" ",array_slice($word,0,$wordLimit));

    if(count($word) > $wordLimit){
        $result .= '<a href="read-more.php?id='.$id.'" class="blog-card-link">Read more <i class="ti-angle-double-right"></i></a>';
    }
    return $result;

}

?>