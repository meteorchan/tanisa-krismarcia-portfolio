<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with Meyawo landing page.">
    <meta name="author" content="Devcrud">
    <title>Tanisa</title>
    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + Meyawo main styles -->
    <link rel="stylesheet" href="assets/css/meyawo.css">
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">

    <!-- Page Navbar -->
    <nav class="custom-navbar" data-spy="affix" data-offset-top="20">
        <div class="container">
            <a class="logo" href="index.php">Tanisa</a>
            <ul class="nav">
                <li class="item active">
                    <a class="link active" href="index.php">Home</a>
                </li>
                <li class="item">
                    <a class="link" href="about.php">About</a>
                </li>
                <li class="item">
                    <a class="link" href="portofolio.php">Portofolio</a>
                </li>
                <li class="item">
                    <a class="link" href="blog.php">Blog</a>
                </li>
                <li class="item">
                    <a class="link" href="contact.php">Contact</a>
                </li>
            </ul>
            <a href="javascript:void(0)" id="nav-toggle" class="hamburger hamburger--elastic">
                <div class="hamburger-box">
                    <div class="hamburger-inner"></div>
                </div>
            </a>
        </div>
    </nav><!-- End of Page Navbar -->

    <!-- page header -->
    <header id="home" class="header">
        <div class="overlay"></div>
        <div class="header-content container">
            
             <h1 class="header-title">
                <span class="up" id="JudulContent"></span>
				
                <span class="down" id="SubJudulContent"></span>
            </h1>
            <p class="header-subtitle" id="isiContent"></p>
			
            <a href="about.php" class="btn btn-primary">Visit About Me</a>
        </div>
    </header><!-- end of page header -->

    <!-- footer -->
    <div class="container">
        <footer class="footer">
            <p class="mb-0">Copyright
                <script>document.write(new Date().getFullYear())</script> &copy; <a
                    href="https://themewagon.com">ThemeWagon</a>
            </p>
            <div class="social-links text-right m-auto ml-sm-auto">
                <a href="javascript:void(0)" class="link"><i class="ti-facebook"></i></a>
                <a href="javascript:void(0)" class="link"><i class="ti-twitter-alt"></i></a>
                <a href="javascript:void(0)" class="link"><i class="ti-google"></i></a>
                <a href="javascript:void(0)" class="link"><i class="ti-pinterest-alt"></i></a>
                <a href="javascript:void(0)" class="link"><i class="ti-instagram"></i></a>
                <a href="javascript:void(0)" class="link"><i class="ti-rss"></i></a>
            </div>
        </footer>
    </div> <!-- end of page footer -->

    <!-- core  -->
    <script src="assets/vendors/jquery/jquery-3.4.1.js"></script>
    <script src="assets/vendors/bootstrap/bootstrap.bundle.js"></script>

    <!-- bootstrap 3 affix -->
    <script src="assets/vendors/bootstrap/bootstrap.affix.js"></script>

    <!-- Meyawo js -->
    <script src="assets/js/meyawo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
	<?php
include "database.php";
$sql = 'SELECT * FROM tblhome';
$result = mysqli_query($conn,$sql);
$jmlData = mysqli_num_rows($result);
if ($jmlData >0){
    while($row = mysqli_fetch_assoc($result)){   
$id =$row["id"]	;
    }
}
?>
    <script>
        function ambilDataDariAPI(id){
            axios.get('api.php?menu=home&id='+id)
                .then(respon => {
                    const data = respon.data;
                    const isiContent = document.getElementById('isiContent');
					const JudulContent = document.getElementById('JudulContent');
					const SubJudulContent = document.getElementById('SubJudulContent');
					isiContent.innerHTML = `${data.isi}`;
                    JudulContent.innerHTML = `${data.judul}`;
                    SubJudulContent.innerHTML = `${data.subjudul}`;						
                })
                .catch(error => {
                    console.error('Error: ', error);
                });
        }
        ambilDataDariAPI(<?php echo $id ?>);
    </script>
</body>

</html>