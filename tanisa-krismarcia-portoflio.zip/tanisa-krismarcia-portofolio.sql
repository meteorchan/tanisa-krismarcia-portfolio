/*
SQLyog Ultimate
MySQL - 10.4.17-MariaDB : Database - web_portofolio
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`web_portofolio` /*!40100 DEFAULT CHARACTER SET utf16 COLLATE utf16_unicode_ci */;

USE `web_portofolio`;

/*Table structure for table `tblabout` */

CREATE TABLE `tblabout` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='Tabel About';

/*Data for the table `tblabout` */

insert  into `tblabout`(`id`,`judul`,`subjudul`,`tgl`,`gbr`,`isi`) values (1,'Who Am I ?','About Me','2023-11-04 16:56:25','assets/imgs/foto-1.jpg','<p>Name : Tanisa Krismarchia</p>\r\n\r\n<p>Hobby : Reading, Drawing and Playing Games</p> \r\n\r\n<p>Work: Skinproof PT Derma Lab Asia</p>\r\n\r\n<p>Studying : Universitas Pembangunan Jaya</p>\r\n\r\n<p>Major : Informatika</p>\r\n\r\n<p>Year : 2021 - now </p>');

/*Table structure for table `tblblog` */

CREATE TABLE `tblblog` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='Tabel Blog';

/*Data for the table `tblblog` */

insert  into `tblblog`(`id`,`judul`,`subjudul`,`tgl`,`gbr`,`isi`) values (1,'Digital Art','(Seni Digital)','2023-11-04 18:04:35','assets/imgs/img-1.jpg','Seni telah menjadi bagian integral dalam peradaban manusia sejak zaman kuno. Namun, perkembangan teknologi digital telah membuka pintu baru untuk ekspresi kreatif: seni digital. Seni digital adalah sebuah bentuk seni yang diciptakan dengan menggunakan perangkat lunak dan peralatan digital, seperti komputer, tablet grafis, dan perangkat penyimpanan data.');
insert  into `tblblog`(`id`,`judul`,`subjudul`,`tgl`,`gbr`,`isi`) values (2,'Role-playing Game','(RPG)','2023-11-04 18:04:53','assets/imgs/img-2.jpg','Permainan peran (RPG), adalah genre game yang telah menarik perhatian pemain selama beberapa dekade. RPG mengundang pemain untuk memasuki dunia fantasi yang kaya dengan karakter, cerita mendalam, dan pilihan berbagai macam.');

/*Table structure for table `tblcontact` */

CREATE TABLE `tblcontact` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `telp` varchar(50) NOT NULL COMMENT 'Telpon',
  `email` varchar(50) NOT NULL COMMENT 'Email',
  `alamat` text NOT NULL COMMENT 'Alamat',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='Tabel Contact';

/*Data for the table `tblcontact` */

insert  into `tblcontact`(`id`,`telp`,`email`,`alamat`,`tgl`) values (1,'Telp : 0851-5696-7962','Email : Tanisakris17chen@gmail.com','Alamat : Jakarta Barat, DKI Jakarta','2023-11-04 17:59:29');

/*Table structure for table `tblhome` */

CREATE TABLE `tblhome` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='Tabel Home';

/*Data for the table `tblhome` */

insert  into `tblhome`(`id`,`judul`,`subjudul`,`tgl`,`gbr`,`isi`) values (1,'Hi!','I am Tanisa','2023-11-04 16:19:14','','<p class=\"header-subtitle\">Welcome to my portofolio</p>');

/*Table structure for table `tblportofolio` */

CREATE TABLE `tblportofolio` (
  `id` int(5) NOT NULL AUTO_INCREMENT COMMENT 'Id',
  `judul` varchar(50) NOT NULL COMMENT 'Judul',
  `subjudul` varchar(50) NOT NULL COMMENT 'Sub Judul',
  `tgl` datetime NOT NULL DEFAULT current_timestamp() COMMENT 'Tanggal',
  `gbr` varchar(50) NOT NULL COMMENT 'Gambar',
  `isi` text NOT NULL COMMENT 'Isi',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='Tabel Portofolio';

/*Data for the table `tblportofolio` */

insert  into `tblportofolio`(`id`,`judul`,`subjudul`,`tgl`,`gbr`,`isi`) values (1,'What I Did ?','Portofolio','2023-11-04 17:28:31','','<div class=\"col-md-4\">\r\n                    <a href=\"#\" class=\"portfolio-card\">\r\n                        <img src=\"assets/imgs/folio-1.jpg\" class=\"portfolio-card-img\"\r\n                            alt=\"Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page\">\r\n                        <span class=\"portfolio-card-overlay\">\r\n                            <span class=\"portfolio-card-caption\">\r\n                                <h4>Menggambar</h5>\r\n                                    <p class=\"font-weight-normal\"></p>\r\n                            </span>\r\n                        </span>\r\n                    </a>\r\n                </div>\r\n                <div class=\"col-md-4\">\r\n                    <a href=\"#\" class=\"portfolio-card\">\r\n                        <img class=\"portfolio-card-img\" src=\"assets/imgs/folio-2.jpg\" class=\"img-responsive rounded\"\r\n                            alt=\"Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page\">\r\n                        <span class=\"portfolio-card-overlay\">\r\n                            <span class=\"portfolio-card-caption\">\r\n                                <h4>Membaca</h5>\r\n                                    <p class=\"font-weight-normal\"></p>\r\n                            </span>\r\n                        </span>\r\n                    </a>\r\n                </div>\r\n                <div class=\"col-md-4\">\r\n                    <a href=\"#\" class=\"portfolio-card\">\r\n                        <img class=\"portfolio-card-img\" src=\"assets/imgs/folio-3.jpg\" class=\"img-responsive rounded\"\r\n                            alt=\"Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page\">\r\n                        <span class=\"portfolio-card-overlay\">\r\n                            <span class=\"portfolio-card-caption\">\r\n                                <h4>Menulis</h5>\r\n                                    <p class=\"font-weight-normal\"></p>\r\n                            </span>\r\n                        </span>\r\n                    </a>\r\n                </div>');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
